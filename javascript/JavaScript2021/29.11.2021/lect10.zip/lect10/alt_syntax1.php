  
<?php
  $fruits= Array("Ябълки", "Банани", "Праскови", "Череши");
  $vegatables= ["Домати", "Пиперки", "Тиквички", "Моркови" ];
 ?>

 <h2>Плодове</h2>
<?php for($i=0, $count=count($fruits); $i<$count; $i++): ?>
	 <div><?= $fruits[$i] ?> </div>
 <?php endfor; ?>

  <h2>Зеленчуци</h2>
<?php foreach ($vegatables as $vegatable):  ?>
   <div><?= $vegatable ?> </div>
<?php endforeach;  ?>