  
<?php
$products=
Array (
   Array("Ябълки", "Банани", "Праскови", "Череши"),
   Array ("Домати", "Пиперки", "Тиквички", "Моркови", "Лук"),
   Array("Кисело мляко", "Сирене", "Кашкавал")
);

?>

 <?php for($i=0, $groups=count($products); $i<$groups; $i++): ?>
 	<ul><?= "Група $i" ?></ul>
 	<?php for($j=0, $count=count($products[$i]); $j<$count; $j++): ?>
       <li><?= $products[$i][$j] ?></li>
    <?php endfor; ?>
 <?php endfor; ?>


  <?php foreach($products as $productGroup): ?>
  	<hr>
 	<?php foreach($productGroup as $product): ?>
       <li><?= $product ?></li>
    <?php endforeach; ?>
 <?php endforeach; ?>

 