  <?php 
       $user= "Ана"; 
       $pass= "123"; 
  ?>  

<?php if(isset($user) && isset($pass)): ?>
	<?php if($user=="Ана" &&  $pass== "123"): ?>
	   <h1 style="color:green"> 
        <?= "Здравей, $user"  ?>
       </h1>
   <?php elseif ($user=="Ана" &&  $pass!= "123" ):  ?>
      <h2 style="color:red"> 
        <?= "Грешна парола, $user"  ?>
      </h2>
   <?php else:  ?>
   	   <h2 style="color:red"> 
   	   	<?= $user  ?>
        <?= "Грешно потребителско име и/или парола"  ?>
       </h2>
   <?php endif;  ?>
<?php else:  ?>
    <h2 style="color:red"> 
      <?= "Моля, логнете се!"  ?>
    </h2>
<?php endif;  ?>