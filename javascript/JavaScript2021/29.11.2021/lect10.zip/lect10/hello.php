<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <title>php start</title>
    
    </head>
    <body>
        <h1>Поздрав</h1>
        <?php
           echo "Здравей, php.<br />";
           echo "Моят любим език<br />";
        ?>
    </body>
</html>