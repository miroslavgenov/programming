<?php
//Деклариране на променливи
$n=10;
$price=1.6;
$isOk=true;
$name="Ana";


//Копиране на променливи
$m=$n;

//Създаване на променливи-референции
$k= &$n;

//Деклариране на константи
define("K", 100);
const PI=3.14;

//Извеждане на стойности на променливи и константи
echo "Cena: {$price}lv <br />";
++$n;
echo "\$n=$n \$k=$k<br />";


echo "Получаване на типа на променлива - ***gettype()***<br />";
echo gettype($n)."<br />";
echo gettype($price)."<br />";
echo gettype($isOk)."<br />";
echo gettype($name)."<br />";


echo"<br />Проверка на дали променливата е от определен тип<br />";
echo "*** gettype()==<тип>, is_<тип> ***<br />";
echo is_bool($isOk)."<br />";
echo is_bool($isOk)?"true":"false"."<br />";



echo "<br />Задаване на типа на променлива- ***settype() ***<br />";
echo gettype($m)."<br />";
settype($m, "double");
echo gettype($m)."<br />";


echo "<br />Проверка дали е зададена дадена променлива- ***isset() ***<br />";
echo isset($m)?"m is set<br />":"m is not set<br />";
echo isset($s)?"s is set":"s is not set<br />";



echo "<br />Унищожаване на променлива ***unset() ***<br />";
unset($price);
echo $price;


// //Масиви
echo "<br />***Arrays ***<br />";
$arr1=Array(5,1,9,3);
$arr2= [8,1,7,2];

echo "<br />Проверка дали е зададена  променлива e масив=> is_array() <br>";
echo is_array($arr1)."<br/>";

echo "<br />Извеждане на масив=> print_r() <br>";

print_r($arr1);

echo "<pre>";
print_r($arr2);
echo "</pre>";

echo "Размер на аrr2: ";
echo count($arr2)."<br />";

$arr2[]=17;

echo "<pre>";
print_r($arr2);
echo "</pre>";

echo "Размер на аrr2: ";
echo count($arr2)."<br />";

// unset($arr2[0]);
// echo "<pre>";
// print_r($arr2);
// echo "</pre>";

// echo "Размер на аrr2: ";
// echo count($arr2)."<br />";





echo "<br />Обхождане на масив=> цикъл по индекс  <br>";
print_r($arr2);
for($i=0, $len=count($arr2); $i<$len; $i++){
    $arr2[$i] *=2;
}
echo "<br />";
print_r($arr2);
echo "<br />";

echo "<br />Обхождане на масив=> цикъл foreach <br>";
//foreach ($arr2 as $element) {
foreach ($arr2 as &$element){
   $element+=5;
}
print_r($arr2);
echo "<br />";


echo "<br />Асоциативни масиви<br>";

$arr3 = ["Burgas"=>8000, "Sofia"=>1000, "Nesebar"=>8230 ];
$arr3["Yambol"]=8600;
echo "<pre>";
print_r($arr3);
echo "</pre>";
echo "<br />Обхождане на aсоц.масив=> цикъл foreach <br>";
 //foreach($arr as $key=>$value)
foreach($arr3 as $city=>$zip){
    echo "$city има код $zip<br />";
}
echo "<br />Обхождане на асоц.масив=> цикъл for <br>";
for(reset($arr3); $key=key($arr3); next($arr3)){
       echo $arr3[$key]."<br />";
}


echo "<br />Преобразуваме на асоц.масив в обикновен array_values()  <br>";

$zips= array_values($arr3);
print_r($zips);



// //Операции  за сравнение
// //=== == != <> !==  > >= < <=  <=>


// // <=>
echo "<br>  Oперация <=> <br>"; 
print_r($arr1);
echo "<br />";
usort($arr1, function($a, $b) {return $a<=> $b;});
print_r($arr1);
echo "<br />";


// echo "<br>  Oперация ?? <br>"; 


?>


