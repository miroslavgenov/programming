<?php
   require_once("sumf.php");

   print_r($_POST);

   if(isset($_POST["aval"]) && isset($_POST["bval"]) ){
   	  $x=$_POST["aval"];
   	  $y=$_POST["bval"];
   	  $res=sum($x, $y);
   	//  echo "suma $res";
   }

?>

<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
      
        <title>Use superglobals</title>
     
    </head>
    <body>
        <form action="first_form.php" method="POST">
        	a<input type="text" name="aval">
        	b<input type="text" name="bval">
        	<button name="sbm">Изпрати данните</button>
        	<div>сума <?= sum($x, $y)??"" ?> </div>
        </form>
         
    </body>
</html>