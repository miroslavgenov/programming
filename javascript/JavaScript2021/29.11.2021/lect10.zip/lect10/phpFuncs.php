
<?php

//Дефиниция и извикване на функция

function sum($a, $b){
    return $a+$b;
}

$res1= sum(1, 7);
echo $res1."<br />";
echo sum(8,19)."<br />";

//Функции за масиви
echo "Масиви параметри<br>";
function aveArr(array $nums){
  //? obiknoven masiv
  $isIndexed= array_values($nums)===$nums;

  $sum=0;
  if( $isIndexed) {
    foreach($nums as $num){
      $sum+=$num;
    }

  }
  else{
    foreach($nums as $key=>$value){
      $sum+=$value;
    }
  }
  return floatval($sum)/count($nums);

}

$marks=["pik"=>6, "oop"=>5, "pe"=>5, "ip"=>6];
$arr= [5,6,4];

echo aveArr($marks)."<br>";
echo aveArr($arr)."<br>";
//Използване на глобални променливи
 // use global

 // $count=10;

 // function incCount(){
 //   //	global $count;
 //   //$count++;
 // 	$GLOBALS["count"]++;
 // }

 // incCount();
 // incCount();
 // echo $count."<br>";


//Задаване на типа на резултата
echo "Функция с тип на резултата int<br>";
function mult(int $x, int $y):int{
	return $x*$y;
}

echo mult(7.8, 3.5)."<br>";//21
echo mult("8", "11")."<br>";//88
echo mult(5,7)."<br>";//35
echo mult("a","b")."<br>";//35
 

//Предаване на параметри
echo "Предаване на параметри<br>";
function test($a, &$b, array &$c){
   	  $a++;
   	  $b++;
   	  for($i=0; $i<count($c); $i++){
   	  	$c[$i]++;
   	  }
   }

   $a=1;
   $b=1;
   $c=[1,2,3];

   test($a, $b, $c); //извикване на test с различни механизми на предаване на параметри
   echo $a."<br>";
   echo $b."<br>";
   echo"<pre>";
     print_r($c);
   echo"</pre>";
  

 // Използване на анонимни функции като параметри

    $sortOption="random";
  // $sortOption="length";
   //$sortOption="standard";
    $names= ["Dina","Ana","Maria", "Aleksandra", "Dimityr" ];

    usort($names, 
    	function($n1, $n2) use ($sortOption){
    	  if($sortOption=="random"){
    	  	return rand(0,2)-1;
    	  }
    	  elseif ($sortOption=="length") {
    	     return strlen($n1)-strlen($n2);
        
    	  }
    	  else{
    	  	return $n1<=>$n2;
    	  }

        }
     );
    echo "Сортиране <br>";

    echo "<pre>";
     print_r($names);
    echo "</pre>";

    // Функции с произволен брой параметри
   echo "Функции с произволен брой параметри <br>";
    function sumAll(){
    	$array=func_get_args();
    	print_r ( $array);
    	$count= func_num_args();
    	echo $count."<br>";
    	$sum=0;
    	for($i=0; $i<$count; $i++){
    		$sum+=func_get_arg($i);
    	}
    	return $sum;

    }

    function multAll(...$list){
    	 $p=1;
    	 foreach($list as $l){
    	 	$p*=$l;
    	 }
    	 return $p;

    }


echo  sumAll(1,2,30)."<br>";
echo multAll(10,2,3)."<br>";
 ?>