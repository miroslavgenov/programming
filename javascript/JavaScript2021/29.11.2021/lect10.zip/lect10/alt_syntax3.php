  
<?php
$products= Array (
  "Плодове"=> Array("Ябълки", "Банани", "Праскови", "Череши"),
  "Зеленчуци"=>Array ("Домати", "Пиперки", "Тиквички", "Моркови", "Лук"),
  "Млечни продукти"=>Array("Кисело мляко", "Сирене", "Кашкавал")
);

?>

  <?php foreach($products as $group=>$groupProducts): ?>
  	<ul><?= $group ?></ul>
 	<?php foreach($groupProducts as $product): ?>
       <li><?= $product ?></li>
    <?php endforeach; ?>
 <?php endforeach; ?>

 