class person{
	constructor(name, age){
		// this.name=name;
       // this.age=age;
       this.name= name!=undefined ?name:"Ivan";
       this.age= age!=undefined?age:20;
	}
	show(){
		console.log(`Име:${this.name} Години:${this.age}`);
	}
}
var p1= new person();
var p2= new person("Svetoslav");
var p3= new person("Tzvetan", 19);
p1.show();
p2.show();
p3.show();

//класове- наследници
class student extends person{
	constructor(name, age, spec, course){
		super(name, age);
		this.spec=spec!=undefined?spec:"KST";
		this.course= course!=undefined?course:1;
	}
	show(){
		super.show();
		console.log(`Specialnost ${this.spec} kurs ${this.course}`);
	}
}
class teacher extends person{
	constructor(name, age, subject){
		super(name, age);
		this.subject = subject!=undefined?subject:"math";
	}
	show(){
		super.show();
		console.log(`Predmet ${this.subject}`);
	}

	
}

var s1= new student();
var s2= new student("Aleksandra", 21, "KST",4);
var s3= new student("Radina", 20, "SI",4);
var t1= new teacher();
t1.name="Ivanov";
t1.age= 40;
var t2= new teacher("Dimov", 45, "databases");
console.log("Students");
s1.show();
s2.show();
console.log("Teachers");
t1.show();
t2.show();

//Композиция - клас, съдържащ масив от обекти
class persons{
	constructor(){
		this.list=[];
	}
	addObject(pObj){
		if(pObj !=undefined){
			this.list.push(pObj);
		}
		else {
            this.list.push(new student());
		}
	}
	addStudent(name, age, spec, course){
		this.list.push(new student(name, age, spec, course));
	}
	showList(){
		this.list.forEach(p=>p.show());
	}

  //ново
  //Връща списък със студенти
  getStudents(){
		return this.list.filter(p=>p instanceof  student);

	}

	//Връща списък със преподаватели
	getTeachers(){
		return this.list.filter(p=> p instanceof teacher);
	}

    //Връща студенти от дадена специалност
	getStudentsBySpec(spec){
		return this.getStudents().filter( s => s.spec===spec);
	}
	
	 //Връща обект със зададено значение value на свойството prop
	findByPropValue(prop, value){
		return this.list.find(p=> p[prop]==value);
	}
	//Средна възраст
	averageAge() {
		return (this.list.reduce((s,p)=>s+p.age, 0)/this.list.length).toFixed(1);
	}

	//Минимална възраст
	minAge(){
	   return this.list.reduce((min, p)=>{
			if(min>p.age) min=p.age;
			return min;}, 100);
	}

	//Сортиране по зададено свойство
	sortByProp(prop){
		this.list.sort(
           (x,y) =>{
           	if(x[prop]<y[prop]) return -1;
           	if(x[prop]>y[prop]) return 1;	
            if(x[prop]==y[prop]) return 0;
           }
		);
	 }

	showNameAge() {
	  this.list.forEach(p=>console.log(p.name+"-" + p.age));
	   
	}



}

//test 
var list1= new persons();
list1.addObject();
list1.addObject(s2);
list1.addObject(s3);
list1.addObject(t1);
list1.addObject(t2);
list1.addStudent("Gergana", 18, "SI", 3);

console.log("\nlist1");
list1.showList();

//Ново
console.log("\nStudents");
console.log(list1.getStudents());
console.log("\nStudents KST");
console.log(list1.getStudentsBySpec("KST"));
console.log("\nTeachers");
console.log(list1.getTeachers());
console.log("\nTest findByPropValue");
console.log("Търсене на обект от списъка name:Aleksandra ");
console.log(list1.findByPropValue("name", "Aleksandra"));
console.log("Търсене на обект от списъка spec:SI ");
console.log(list1.findByPropValue("spec", "SI"));
console.log("Търсене на обект от списъка subject:databases ");
console.log(list1.findByPropValue("subject", "databases"));


console.log("\nSpisyk");
list1.showNameAge()
console.log("Sr.vyzrast:"+ list1.averageAge());
console.log("Min.vyzrast:"+ list1.minAge());

console.log("\nSpisyk, sortiran  po ime\n");
list1.sortByProp("name");
list1.showNameAge()
console.log("\nSpisyk, sortiran  po godini\n");
list1.sortByProp("age");
list1.showNameAge()