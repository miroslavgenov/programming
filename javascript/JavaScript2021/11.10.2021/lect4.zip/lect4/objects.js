//1. Oбектни литерали
var user = {nick:"rocker", posts:1000};
console.log(user);

//Добавяне на свойство
user.isAdmin=true;
console.log(user);

//in проверява дали дадено свойство се съдържа в обекта
console.log("\nin");
console.log("nick" in user);
console.log("name" in user);

delete user.isAdmin;
console.log(user);

//Обектите могат да имат свойства-функции
var p1= {name:"Ivan", 
         age:20,
         show:function(){
         	console.log(`${this.name} na ${this.age} godini`);
         }
};
var p2= {name:"Dimo", 
         age:19,
         show:function(){
         	console.log(`${this.name} na ${this.age} godini`);
         }
};
console.log(p1);
console.log(p2);

//обръщение към свойствата
console.log(p1.name);
console.log(p1["name"]);

//for-in
console.log("for in loop");
for(prop in p1){
	console.log(p1[prop]);
}


//до EcmaScript 6
//Функция - конструктор
console.log("using constructors");
function Person (name, age){
    this.name=name;
    this.age=age;
}
//всички обекти, създадени с дадения конструктор,
//наследяват свойства от прототипа на конструктора
console.log('Person prototype:',Person.prototype);
Person.prototype.show= function(){
	console.log(`${this.name} e na ${this.age}`);
}
console.log('Person prototype:',Person.prototype);

var pers1= new Person("Miroslav",20);
var pers2 = new Person("Heidzan", 21);
pers1.show();
pers2.show();

console.log(pers1 instanceof Person);