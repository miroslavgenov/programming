// show the whole html document
// access the document
console.log(document);
console.log();
