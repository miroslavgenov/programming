console.log(document.getElementById("p4"));

document.getElementById("p4").textContent = "hello paragraph 4";
