// access element like in css selector
// access the first element
var p = document.querySelector("p");
console.log(p);
console.log();

// return null
console.log(document.querySelector("frame"));
