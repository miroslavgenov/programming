// relatioship parent child
// and return all childrens of the
// body with empty text nodes
console.log(body.childNodes);
console.log("type of body.childNodes", typeof body.childNodes);
console.log();

// body.children dava vlojenite elementi direktno v children
// this body.children is like list
var children = body.children;
console.log(children);
console.log("typeof children -> ", typeof children);
console.log("children.lenght= ", children.length);
console.log(children[5]);
console.log();
