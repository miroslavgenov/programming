//select all
var p_name_message_all = document.querySelectorAll('p[name="message"]');
p_name_message_all[2].textContent = "modified 3";
console.log(p_name_message_all[0].textContent, p_name_message_all[1]);
console.log();
