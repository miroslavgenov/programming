console.log(document.getElementsByClassName("sel"));
