// show what is in the body tag
//access to document
console.log(document.body);
console.log();

var body = document.body;
console.log("typeof body -> ", typeof body);
console.log();
