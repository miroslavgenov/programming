// select by name p[name="message"] , by class .sel by id #p4
var p_name_message1 = document.querySelector('p[name="message"]');
console.log(p_name_message1);
console.log();
