console.dir(document);
var body= document.body;
console.log(body);

console.log("childNodes");
console.log(body.childNodes);

console.log("children");
console.log(body.children);

var h1= body.firstElementChild;
var scr= body.lastElementChild;
var parent= body.parentNode; 

console.log(h1);
console.log(scr);
console.log(parent);

var firstPar= h1.nextElementSibling;
var ul= scr.previousElementSibling;

console.log(firstPar);
console.log(ul);

//Преки методи за достъп до елементите на DOM
//document.getElementsByTagName('tag');
//document.querySelectorAll('selector');

var all_pars1= document.getElementsByTagName('p');
var all_pars2=document.querySelectorAll('p');
console.log(all_pars1);
console.log(all_pars2);

for(var i=0, len=all_pars1.length; i<len; i++){
	console.log(all_pars1[i].innerText);
}

var all_pars1_arr=Array.from(all_pars1);
//all_pars1_arr.forEach(p=>p.style.color="#7ab");
//all_pars1_arr.forEach(p=>p.style.fontSize="10px");

//Преки методи за достъп до елементите на DOM
//document.getElementsByClassName('tag');
//document.querySelectorAll('selector');

var pars23_1 = document.getElementsByClassName('myClass');
var pars23_2 = document.querySelectorAll('.myClass');

console.log(pars23_1);
console.log(pars23_2);

var pars_23A= Array.from(pars23_2);
pars_23A.forEach(p=>p.className="yourClass");

//document.getElementById('id');
//document.querySelector('selector');

var ul= document.getElementById('myCity');

h1.id="title";
//h1.setAttibute("id","title" );
var h1_2= document.querySelector('#title');

h1_2.style.border ="5px solid green";

//firstPar.innerText +="-моят любим град";

all_pars1[3].innerText +="-моят любим град";

//Създаване/премахване +

var new_city= document.createElement("li");
new_city.innerText = "Ветрен";

ul.appendChild(new_city);

var btn= document.getElementById('btn');
var text = document.getElementById('txt');

btn.addEventListener("click", addCity);

function addCity(){
	var new_city= document.createElement("li");
    new_city.innerText = text.value;

   ul.appendChild(new_city);
   text.value="";
}