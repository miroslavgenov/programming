
var body= document.body;
var ul1= document.querySelector("ul");

var btnClone= document.querySelector("#btnClone");
var btnAdd= document.querySelector("#btnAdd");
var btnDisplace= document.querySelector("#btnDisplace");
var btnInsert= document.querySelector("#btnInsert");
var btnReplace= document.querySelector("#btnReplace");
var btnRemove= document.querySelector("#btnRemove");

btnClone.addEventListener("click", CloneList);
btnAdd.addEventListener("click", AddNodeLast);
btnDisplace.addEventListener("click", DisplaceNodes);
btnInsert.addEventListener("click", InsertNewNode);
btnReplace.addEventListener("click", ReplaceNode);
btnRemove.addEventListener("click", RemoveNodes);

function CloneList(){
	var ul2= ul1.cloneNode(true);
	var h2 =document.createElement("h2");
    h2.innerHTML="Списък 2 - клониран списък 1";
    body.appendChild(h2);
    body.appendChild(ul2);
}



function AddNodeLast(){
	var new_li1= document.createElement("li");
    new_li1.innerText="грозде";
    ul1.appendChild(new_li1);
 }

 function  DisplaceNodes(){
	var first=ul1.firstElementChild;
	var second= first.nextElementSibling;
    ul1.insertBefore(second, first); //възел за вмъкване, преди кой
 }

  function  InsertNewNode(){
      var new_li2= document.createElement("li");
      new_li2.innerText="банани";          
      ul1.insertBefore( new_li2, ul1.firstElementChild);
      				 //нов възел, преди кой
  }




function  ReplaceNode(){
	new_li3= document.createElement("li");
    new_li3.innerText="сливи";
    ul1.replaceChild(new_li3, ul1.children[1] );  // //нов възел, на мястото на кой
 }


function  RemoveNodes(){
	var ul2=document.querySelectorAll('ul')[1];
    ul2.children[2].remove(); // 3-ти елемент
	ul2.removeChild(ul2.children[0]);
 }




