/* За проследяване на  действията на опараторите премахнете последователно коментарите
под съответната точка */

// Обект DOCUMENT 
// console.log("\ndocument");
// console.dir(document);
// console.log("\ndocument.body");
// console.log(document.body);
// console.log("\ndocument.all");
// console.log(document.all);
// console.log("\ndocument.all[2]");
// console.log(document.all[2]);
// console.log("\ndocument.childNodes");
// console.log(document.childNodes);
// console.log("\ndocument.body.childNodes");
// console.log(document.body.childNodes);
// console.log("\ndocument.body.children");
// console.log(document.body.children);


//1. Селектиране на елементи по име на тага
// GetElementsByTagName("tag")
// querySelectorAll("tag") 


console.log("getElementsByTagName('tag'), querySelectorAll('tag') ");
var pars= document.getElementsByTagName("p");
console.log(pars);  // pars - HTML collection
var pars1=document.querySelectorAll("p");
console.log(pars1); //pars1- NodeList collection

//Обръщание към определен елемент от колекцията
pars[0].innerText += ", редактиран ***"; // Про,еняме текста на параграфа

for(var i=0; i<pars.length; i++){
	pars[i].style.fontSize="20px";
}
 var parsArray = Array.from(pars);  //получаваме масив от колекцията
 //Към масива можем да прилагаме методи-итератори
parsArray.forEach( (par)=>par.style.fontStyle="italic");



//1. Селектиране на елемент по id
// GetElementById"tag")
// querySelector("#id") 

/*nsole.log("getElementById('id'),querySelector('#id')" );
var h1= document.getElementById("header1");
var h2=document.querySelector("#header2");
h1.style.border="2px solid #60f";
h1.style.color="#aab";
h2.style.backgrowndColor="fc9"; */

//getELementsByClassName
console.log("getELementsByClassName('class'),querySelectorAll('.class')" );
var par23=document.getElementsByClassName("myclass");
var par23N= document.querySelectorAll(".myclass");
console.log(par23);
console.log(par23N); 



// for(var i=0; i<par23.length; i++){
// 	par23[i].className="yourclass";
// }
for(var i=0; i<par23N.length; i++){
	par23N[i].classList.add("bg_class");
}

var images=document.images;
console.log(images);
var imArr= Array.from(images);
imArr.forEach( (im)=>im.classList.toggle("photo"));