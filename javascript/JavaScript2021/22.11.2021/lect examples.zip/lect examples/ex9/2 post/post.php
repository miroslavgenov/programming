<?php
if(isset($_POST['msg1'])){
    echo "POST: Hello {$_POST['msg1']}";
}

if(isset($_POST['msg2'])){
    echo "POST: Hello {$_POST['msg2']}";
}
?>
