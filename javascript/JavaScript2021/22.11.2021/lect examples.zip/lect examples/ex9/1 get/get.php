<?php 
if(isset($_GET['msg1'])){
    echo "GET: Hello {$_GET['msg1']}";
}

if(isset($_GET['msg2'])){
    echo "GET: Hello {$_GET['msg2']}";
}
?>