fetch("javascript.js")
  .then((val) => val.text())
  .then((val) => console.log(val));
