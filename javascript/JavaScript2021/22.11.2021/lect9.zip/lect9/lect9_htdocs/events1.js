let body= document.body;
console.log(body.childNodes);
console.log(body.childNodes.length);

