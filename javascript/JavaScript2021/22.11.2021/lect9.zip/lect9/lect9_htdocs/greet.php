<?php

echo "from server...";
if(isset($_GET['name']))
	echo "GET: hello {$_GET['name']}!";

if(isset($_POST['name']))
	echo "POST: hello {$_POST['name']}!";