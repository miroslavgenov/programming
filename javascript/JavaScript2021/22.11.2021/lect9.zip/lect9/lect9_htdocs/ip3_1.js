
var arr=[1,2,3];
var f=var(function(x){

})
var process=function(x){
	return f();
}

var p=process();
console.log(p);

