<?php
if (isset ($_GET['yourname'])){
	$name=$_GET['yourname'];
}
if (isset ($_POST['yourname'])){
	$name=$_POST['yourname'];
}

try {
   $conn = new PDO("mysql:host=localhost;dbname=ajax; charset=utf8", "root", "");
    echo "OK! " ;
  $query=   "INSERT INTO users( name) VALUES (:name)";
  $stm=$conn->prepare($query);

  $stm->bindParam(':name', $name);
  $stm->execute();
  echo "Потребителят е добавен!";
}
catch(PDOException $e)
    {
    echo "Error: " . $e->getMessage();
}