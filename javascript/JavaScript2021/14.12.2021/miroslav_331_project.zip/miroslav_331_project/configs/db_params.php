<?php 

// echo "HELLO DB PARAMS<br>";

return array(
    "host"=>"localhost",
    "dbname"=>"miroslav_331_prog_language",
    "user"=>"root",
    "password"=>"",
);


?>