<?php 

return array(
    "miroslav_331_project/list/all"=>"language/listAll", # show list with all languages
    "miroslav_331_project/year/(\d+)"=>"language/year/$1", # show list with language created from year
    "miroslav_331_project/inforate/(\d+)"=>"language/infoRate/$1",#show the info of the first 5 numbers
    "miroslav_331_project/добави"=>"language/add", # add language in the data base

);

?>