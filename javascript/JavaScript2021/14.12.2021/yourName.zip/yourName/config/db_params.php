<?php
 return array(
     'host'=>'localhost',
     'dbname'=>'users',
	  'user'=>'root',
	  'password'=>''
 	);
 ?>