<?php

class AdminController{

	public function actionIndex(){
      echo  "<h3>***Mетод actionIndex() на класа AdminController***</h3>";
      return true;
	}

}