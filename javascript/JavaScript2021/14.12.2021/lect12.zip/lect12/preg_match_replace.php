<?php
echo 'preg_match(pattern, string)<br />';
$pattern = "/Java/";
$pattern1 = "~php~";

$s1 ="Обичам Java";
$s2= "JavaScript e любимият ми език";

$res1 = preg_match($pattern, $s1);
echo $res1."<br />";
echo preg_match($pattern1, $s2)."<br >";
echo preg_match($pattern, $s2)."<br >";

echo "<br /> preg_replace(pattern, replacement, string)<br >";
$pattern = "~([А-Я]+) (\d+)~"; // FN КСТ 121 Е 18 СИ 54
$string = "СИ 320";
$replacement = "Специалност $2  номер $1";

$res2= preg_replace($pattern, $replacement, $string);

$list =["КСТ 12", "СИ 1245", "Е 615", "Si 19", "сиiii 67"];
echo $res2."<br /><br />";


foreach($list as $fn){
	echo preg_replace($pattern,  $replacement, $fn)."<br />";
}




?>