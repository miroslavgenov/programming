<?php
$arr= Array(1,2,3);
//$arr= [1,2,3];
?>