<?php

include_once ('data1.php'); //$arr= Array(1,2,3);
print_r( $arr);
echo "<br>";


$arr2= include('data2.php');
print_r( $arr2);
echo "<br>";
$arr3 = include("data2.php");
print_r( $arr3);
echo "<br>";


?>