<?php
   class NewsController{
   	  public function actionIndex(){
   	  	 echo " Метод actionIndex на класа NewsController<br >";

   	  }
   	  public function actionList(){
   	  	 echo " Метод actionList на класа NewsController<br >";

   	  }

   	  public function actionView1($params){
           echo " Метод actionView1 на класа NewsController<br >";
           echo "<pre>";
           print_r($params);
            echo "</pre>";

   	  }

   	   public function actionView2($section, $id){
           echo " Метод actionView2 на класа NewsController<br >";
           echo "section = $section.<br />";
            echo "id = $id.<br />";


      }
      //  public function actionView($params){
      //      echo " Метод actionView (\$params)  на класа NewsController<br >";
      //      echo "Получени параметри";
      //      echo "<pre>";
      //      print_r($params);
      //       echo "</pre>";

   	  // }

   	   public function actionView($section, $id){
      echo " Извикан е метод actionView(\$section, \$id) на класа NewsController<br >";
            echo "Получени параметри<br />";
           echo "\$section = $section.<br />";
            echo "\$id = $id.<br />";


      }
  }
   
   class StoriesController{
   	    public function actionIndex(){
   	  	 echo " Метод actionIndex на класа NewsController<br >";

   	  }
   }
  //Asoc. masiv pattern - replacement (route)
   $routes =  Array  (
   	 "asen/news/([a-z]+)/([0-9]+)" =>"news/view/$1/$2",
   	 "asen/news"=>"news/index",
   	 "asen/stories"=>"stories/index",
   	 "asen/list"=>"news/list"
   );

 // $uri = "asen/list";
  // $uri = "asen/news/movies/12";
 $uri = "asen/news/business/125";
   echo "Въведен адрес  $uri <br />";


   foreach ($routes as $pattern=>$route)
   {
     if(preg_match ("~$pattern~", $uri)) {
     	echo "$uri oтговаря на шаблона $pattern .<br> ";
        
        //съставки на адреса

        $parts= explode('/', $route);
    

        echo "Части<br />";
          echo "<pre>";
           print_r($parts);
          echo "</pre>";

         $count = count($parts);
         echo "Брой  $count<br />";

         if ($count>2 ) {
         	$realRoute = preg_replace("~$pattern~", $route, $uri);
            echo 	"\$realRoute: $realRoute.<br />";
            
            $parts=explode('/', $realRoute);

         }
         echo "<br />Съставки на реалния маршрут<br >";
          echo "<pre>";
           print_r($parts);
          echo "</pre>";

          //Клас на контролера
          $controlerName=ucfirst (array_shift($parts))."Controller";
          echo "\$controlerName= $controlerName<br />";
           echo "<br />Съставки след извличане на контролера<br >";
          echo "<pre>";
           print_r($parts);
          echo "</pre>";

          $actionName= 'action'.ucfirst(array_shift($parts));
           echo "\$actionName= $actionName<br />";

           echo "<br /><br />Съставки след извличане на метода<br >";
          echo "<pre>";
           print_r($parts);
          echo "</pre>";

          $params = NULL;
           if($count >2){
           	 $params= $parts;
           }
          
           echo "<br />Параметри<br >";
          echo "<pre>";
           print_r($params);
          echo "</pre>";


          //Създаване на обект от класа на контролера
          $controlerObj= new  $controlerName();
        // подаване на параметри като масив
        // $controlerObj->$actionName($params);
         // подаване на параметри като променливи с подходящи имена
          call_user_func_array(Array($controlerObj, $actionName), $params);
         break;
     }

   
     else{
     	echo "$uri НЕ oтговаря на $pattern.<br> ";
     }

}


?>