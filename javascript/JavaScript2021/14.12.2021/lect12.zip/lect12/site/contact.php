<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
    </head>
    <body>
        <h1>Vryzki s nas</h1>
        <a href="index.php">Home</a>
        <a href="about.php">About us</a>
         <a href="contact.php">Contact us</a>
        <footer>Created &copy 2019</footer>
    </body>
</html>