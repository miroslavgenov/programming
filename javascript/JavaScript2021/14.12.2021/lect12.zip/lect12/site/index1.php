<?php  require_once "includes/header.php"; ?>
        <h1>Home</h1>
 <?php   require_once "includes/footer.php"; ?>       