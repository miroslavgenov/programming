<?php  require_once "includes/header.php"; ?>
        <h1>Za firmata</h1>
 <?php  require_once "includes/footer.php"; ?>       