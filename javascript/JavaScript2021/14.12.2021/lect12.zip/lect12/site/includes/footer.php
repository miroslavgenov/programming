        <a href="index1.php">Home</a>
        <a href="about1.php">About us</a>
         <a href="contact1.php">Contact us</a>
        <footer>Created &copy 2019</footer>
    </body>
</html>