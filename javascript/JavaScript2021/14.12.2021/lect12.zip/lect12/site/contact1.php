<?php  require_once "includes/header.php"; ?>
        <h1>Връзки с нас</h1>
 <?php  require_once "includes/footer.php"; ?>       