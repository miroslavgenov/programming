
var pattern = /a/i;
console.log(`Шаблон: ${pattern}`);
console.log(`${pattern}.test("Ani"): ${pattern.test("Ani")}`);
console.log(`${pattern}.test("Nina"): ${pattern.test("Nina")}`);
console.log(`${pattern}.test("Nina"): ${pattern.test("Eli")}`);


console.log("\nПозиционни индикатори: ^, $");
console.log(`/^a/i.test("Ani"):${/^a/i.test("Ani")}`);
console.log(`/^a/i.test("Nina"):${/^a/i.test("Nina")}`);
console.log(`/a$/i.test("Varna"):${/a$/i.test("Varna")}`);
console.log(`/a$/i.test("Burgas"):${/a$/i.test("Burgas")}`);

var regex = /^К/;
console.log(`Шаблон: ${regex}`);
var names = ["Кирил Янев", "Антон Попов", "Камелия Иванова"];
console.log("Масив names: "+ names);
console.log("Намерени съвпадения в масива names");
for(var name of names) {
    if(regex.test(name)) {
        console.log(name);
    }
}


console.log("\nДиапазони от символи: [...]");
var patternCyr = /^[А-Я][а-я]+$/;
console.log(`Шаблон: ${patternCyr}`);
var array= ["Яна", "КСТ11", "Кока кола", "Фанта"]
console.log("Масив array: "+ array);
console.log("Намерени съвпадения в масива array");
for(var el of array) {
    if(patternCyr.test(el)) {
        console.log(el);
    }
}

console.log("\nКласове символи \\d- цифра");
var patternTel= /^0\d{3}-\d{3}-\d{3}/;
console.log(`Шаблон: ${patternTel}`);
console.log(`${patternTel}.test("0778-762-989"): ${patternTel.test("0778-762-989")}`);
console.log(`${patternTel}.test("02-123-456"): ${patternTel.test("02-123-456")}`);

console.log("\nКласове символи \\w- латинска буква, цифра или _");
var symbols= ["R", "q", "-","ж", "1", "_", "Я"];
var wordPattern = /\w/;
console.log(`Шаблон: ${wordPattern}`);
console.log("Масив symbols: "+ symbols);
console.log("Намерени съвпадения в масива symbols");
for(var s of symbols) {
    if(wordPattern.test(s)) {
        console.log(s);
    }
}
console.log("\nКласове символи \\W- специален символ");
var patternSpecSymbol = /\W/g;
console.log(`Шаблон: ${patternSpecSymbol}`);
var pass = "t5&gs*(@";
console.log("Низ: "+ pass);
console.log("Намерени съвпадения при глобално търсене с match");
var result = pass.match(patternSpecSymbol);
console.log(result);
console.log("\nПодизрази");
var patternSub = /[0-9]{4,6}\s(\w{3,}), (\w{3,})/ ;
var cities =["8000 Burgas, Bulgaria", "10115 Berlin, Germany",
            "101000 Moscow, Russia"];

cities.forEach(c=> {if(patternSub.test(c)) 
	                console.log(RegExp.$2+"-"+RegExp.$1);})