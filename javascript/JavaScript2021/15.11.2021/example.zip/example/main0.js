var f = document.forms[0];
console.log(f);

var f1 = document.getElementsByTagName("form");
console.log(f1[0]);

var f2 = document.myform;
console.log(f2);
