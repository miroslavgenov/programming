var f = document.myform;

var textarea = f.ta;
textarea.value = "Burgas\nVarna\nSlaveikov";
textarea.cols = 5;
textarea.rows = 40;
