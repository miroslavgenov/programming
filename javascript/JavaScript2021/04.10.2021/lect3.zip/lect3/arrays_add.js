var arr=[7, 11, 1, 22, 110, 5];
console.log(arr);
arr.sort();
console.log("Сортиран по подразбиране");
console.log(arr);