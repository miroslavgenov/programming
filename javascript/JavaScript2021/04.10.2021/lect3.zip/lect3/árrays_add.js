var arr=[7, 11, 1, 22, 110, 5];
console.log(arr);
arr.sort();
console.log("Сортиран по подразбиране");
console.log(arr);

arr.sort(function(a,b){
	if(a<b) return -1;
	if(a>b) return 1;
	return 0;
});

//arr.sort((a,b)=>a-b);

console.log("Сортиран по нарастване");
console.log(arr);

//arr.sort(function(a,b){return b-a;})
arr.sort((a,b)=>b-a);
console.log("Сортиран по намаляване");
console.log(arr);

//Oбръщане на масив
var arr2=[1,9,2]; console.log(arr2);
arr2.reverse();
console.log(arr2);

//Преобразуване на масив в string
var names=["Ana", "Petyr", "Nina"];
//var names_str = names.join();
var names_str = names.join('-');
console.log(names_str);

var date1="2021.10.4";

var date2=date1.split('.').reverse().join('/');
console.log(date2);