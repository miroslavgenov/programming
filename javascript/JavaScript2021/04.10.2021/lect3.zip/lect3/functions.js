
console.log(sum(1,3));
//Функция-дефиниция
function sum(a,b){
	return a+b;
}

var s1= sum(1,10);
console.log(s1);

var s2= sum(7,8,9);
console.log(s2);

var s3=sum();
console.log(s3);

//Функция - израз
//console.log(diff(1,4)); //Ne!
var diff= function (a,b) {
	return a-b;
}

console.log(diff(8,2));

console.log("arguments, this");
var sumAll= function(){
	console.log(this);
	console.log(arguments);

	console.log("isArray arguments?"+Array.isArray(arguments));
//var 1
    var sum=0;
    for(var i=0, len=arguments.length; i<len; i++){
    	sum+=arguments[i];
    }
    return sum;

    //var 2
    var arrAgrs=Array.from(arguments);
    console.log("isArray arrArgs?"+Array.isArray(arrAgrs));
    var sum2= arrArgs.reduce((sum, el)=>sum+el);
    return sum2;

}

console.log(sumAll(1,2,4));
console.log(sumAll(1,7,10,200, 1000));

console.log("let vs var");

var b=10;
{
	var b=100;
}
console.log(b); //100

let c=1;
{
	let c=1000;
}
console.log(c); //1


//Функции-параметри (callback functions)

var process= function(a, f1, f2){
	return f1(a) +f2(a);
}
var mult10= function(x){return x*10;}
var add100= function(x){return x+100;}

var res1= process(5, mult10, add100);
console.log(res1);


//Самоизвикваща се функция
(function (){
	console.log("Здравей");
})();

(function (name){
	console.log("Здравей,"+name);
})("Мирослав");

var drink="kafe";
var f= function(eat){
	//var eat="sandwich";
	var show = function(){
		console.log(eat+ " s "+ drink );
	}
	return show;
}

//console.log(eat);
var f1= f("sandwich");
f1();
var f2= f("kroasan");
f2();