console.log("Maсиви");

var empty = [];
console.log(empty);
console.log("length:"+empty.length);

var names= ["Мирослав", "Виктория", "Кристияна", "Мартин", "Даниел"];
console.log(names);
console.log("Broi:"+names.length);

//Добавяне в края
names[5]="Радина";
names[6]="Димо";
names.push("Aлександра","Светослав","Хейджан", "Цветан");
console.log(names.length);
console.log(names);

names.unshift("Aни", "Виолета", "Георги");
console.log(names);

//Обединяване - metod concat
var list = ["Хорие", "Тодор", "Смаил", "Айхан", "Радослав"].concat(names);
console.log(list);

//Цикли за обхождане на масиви
for(var i=0, len=list.length; i<len; i++){
	console.log(list[i], "-", list[i].charAt(0));
}

//for-in
var numbers=[1,4,11];
numbers[6]=3;
console.log(numbers);
for(var i=0, len=numbers.length; i<len; i++){
	console.log(numbers[i]);
}

console.log("for-in");
for(var index in numbers){
	console.log(numbers[index]);
}

console.log("for-of");
for(var element of numbers){
	console.log(element);
}
console.log(list);
var first3= list.slice(0, 3);
for(var name of first3){
	console.log(`${name} - ${name.length}`)
}

var names1= names;
console.log(names1);
console.log(names);
names[0]="Maртина";
console.log(names1);
console.log(names);

console.log("deep copy");
var names2= names.slice();
var names3=[...names];
names[0]="Иван";
console.log(names);
console.log(names2);
console.log(names3);

console.log("splice");
names2.splice(1,5);
console.log(names2);
names2.splice(0,3, "Aсен", "Петър");
console.log(names2);

var idxPetyr= names2.indexOf("Петър"); //1
var idxNina=names2.indexOf("Nina");//-1

console.log("find, findIndex");
var longName= names2.find(function(x){return x.length>=7;});
console.log(longName);
var longNameIdx=names2.findIndex(x=>x.length>=7);
console.log(longNameIdx);


console.log("forEach");
list.forEach(x=>console.log(x));

var firstLetters=list.map(x=>x.charAt(0));
console.log(firstLetters);

console.log("map");
var arr=[1,2,3];
var doubled=arr.map(x=>x*2);
console.log(doubled);

console.log("filter");
var includesA=list.filter(x=>x.includes("а"));
console.log(includesA);

console.log("some, every");
var n1=[8,3,2,4,6];
var res1= n1.some(x=>x%2==0);// true
var res2= n1.every(x=> x%2==0); //false

console.log("sum");
var sum=n1.reduce((s,el)=>s+el);
console.log(sum);

var firstL=list.reduce((s,el)=>s+el.charAt(0), "");
console.log(firstL);

//Тодор и Кристияна -
si1118@abv.bg



	