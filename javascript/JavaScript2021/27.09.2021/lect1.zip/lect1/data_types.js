console.log("***Tипове данни***");

var a;
console.log(a);
console.log("a="+a);
console.log("tip:"+typeof(a));

a=7.5;
console.log("a="+a);
console.log("tip:"+typeof(a));

a=true;
console.log("a="+a);
console.log("tip:"+typeof(a));

var n1= "Иван";
var n2= "Иван";
//Примитивен тип string - сравняват се стойностите
console.log(n1==n2); //true

var ref1= new String("Асен");
var ref2= new String("Асен");
console.log(ref1==ref2); //false, сравняват се референциите

console.log("Oсновни методи на класа стринг");	
//дължина на низа
var name= "Димо Станимиров Димов";
var chars= name.length- 2; //брои букви в името
console.log(chars);

var allSmall= name.toLowerCase();
console.log(allSmall);

//[], charAt() - символ на определена позиция
console.log(name[1]);//и

//търсене - indexOf(niz [,startova pos])
//index на първото срещане, -1
var i1= name.indexOf("Ди");
console.log(i1);//0
var i2= name.indexOf("Ди",1);
console.log(i2);//16

//отделяне на подниз
//slice(start index, end index+1);
var name2= "Кристияна Живкова Ангелова";

var space1=name.indexOf(" ");
var first1 = name.slice(0, space1);
console.log(first1);

var space2=name2.indexOf(" ");
var first2 = name2.slice(0, space2);
console.log(first2);

//без втори параметър - до края
var space2_k= name2.indexOf(" ", space2+1);
var fam2a= name2.slice(space2_k+1);
var fam2b= name2.slice( -(name2.length-space2_k-1));
console.log(fam2a);
console.log(fam2b);

var words =name2.split(" ");
console.log(words);

var letters= name2.split("");
console.log(letters);