(function(_ds){var window=this;try{window.customElements.define(_ds.Xg(),_ds.ah)}catch(a){console.warn("Unrecognized DevSite custom element - DevsitePanel",a)};})(_ds_www);
