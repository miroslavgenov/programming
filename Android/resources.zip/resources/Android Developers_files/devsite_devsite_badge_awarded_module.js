(function(_ds){var window=this;try{window.customElements.define("devsite-badge-awarded",_ds.dF)}catch(a){console.warn("Unrecognized DevSite custom element - DevsiteBadgeAwarded",a)};})(_ds_www);
