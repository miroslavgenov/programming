(function(_ds){var window=this;try{window.customElements.define(_ds.Wg(),_ds.$g)}catch(a){console.warn("Unrecognized DevSite custom element - DevsitePanel",a)};})(_ds_www);
