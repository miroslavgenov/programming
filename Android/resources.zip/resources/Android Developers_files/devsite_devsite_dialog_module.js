(function(_ds){var window=this;try{window.customElements.define("devsite-dialog",_ds.nq)}catch(a){console.warn("devsite.app.customElement.DevsiteDialog",a)};})(_ds_www);
